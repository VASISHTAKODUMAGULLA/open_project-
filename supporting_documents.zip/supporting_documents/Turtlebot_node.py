import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist, TransformStamped
import tf2_ros
import math


class TurtlebotNode(Node):
    def __init__(self):
        super().__init__('turtlebot')
        self.publisher_ = self.create_publisher(Twist, '/turtlebot/cmd_vel', 10)
        self.tf_buffer = tf2_ros.Buffer()
        self.tf_listener = tf2_ros.TransformListener(self.tf_buffer, self)

    def move_to_position(self, x, y):
        transform = self.get_transform('world', 'turtlebot')
        if transform is not None:
            turtlebot_x = transform.transform.translation.x
            turtlebot_y = transform.transform.translation.y
            distance = math.sqrt((x - turtlebot_x) ** 2 + (y - turtlebot_y) ** 2)
            while distance > 0.1:
                cmd_publish = Twist()
                cmd_publish.linear.x = 0.1  # Adjusting the linear velocity
                self.publisher_.publish(cmd_publish)
                rclpy.spin_once(self)
                transform = self.get_transform('world', 'turtlebot')
                if transform is not None:
                    turtlebot_x = transform.transform.translation.x
                    turtlebot_y = transform.transform.translation.y
                    distance = math.sqrt((x - turtlebot_x) ** 2 + (y - turtlebot_y) ** 2)
            self.stop_moving()

    def stop_moving(self):
        cmd_publish = Twist()
        cmd_publish.linear.x = 0.0
        self.publisher_.publish(cmd_publish)

    def get_transform(self, source_frame, target_frame):
        try:
            transform = self.tf_buffer.lookup_transform(source_frame, target_frame, rclpy.time.Time())
            return transform
        except (tf2_ros.LookupException, tf2_ros.ConnectivityException, tf2_ros.ExtrapolationException):
            return None

    def destroy_node(self):
        cmd_publish = Twist()
        self.publisher_.publish(cmd_publish)
        super().destroy_node()


def main(args=None):
    rclpy.init(args=args)
    turtlebot_node = TurtlebotNode()

    try:
        while rclpy.ok():
            transform = turtlebot_node.get_transform('tello', 'turtlebot')
            if transform is not None:
                turtlebot_node.stop_moving()  # Stoping the Turtlebot's movement
                x = transform.transform.translation.x
                y = transform.transform.translation.y
                turtlebot_node.move_to_position(x, y)
            rclpy.spin_once(turtlebot_node)
    except KeyboardInterrupt:
        pass

    turtlebot_node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
