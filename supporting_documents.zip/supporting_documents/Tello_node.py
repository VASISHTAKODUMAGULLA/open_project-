import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
import cv2
import numpy as np
import tf2_ros
from geometry_msgs.msg import TransformStamped
from tello_msgs.srv import TelloAction


class TelloNode(Node):
    def __init__(self):
        super().__init__('tello')
        self.publisher_ = self.create_publisher(Twist, '/drone1/cmd_vel', 10)
        self.bridge = CvBridge()
        self.subscription = self.create_subscription(
            Image,
            '/drone1/image_raw',
            self.camera_callback,
            10
        )
        self.red_cube_detected = False
        self.tf_broadcaster = tf2_ros.TransformBroadcaster(self)
        self.tf_buffer = tf2_ros.Buffer()
        self.tf_listener = tf2_ros.TransformListener(self.tf_buffer, self)
        self.vicinity_threshold = 0.5  # Adjusting the threshold
        self.tello_coordinates = None

        # Creating TelloAction client
        self.cli = self.create_client(TelloAction, '/drone1/tello_action')
        while not self.cli.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('Service not available, waiting again...')
        self.req = TelloAction.Request()

    def camera_callback(self, msg):
        cv_image = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
        hsv_image = cv2.cvtColor(cv_image, cv2.COLOR_BGR2HSV)
        lower_red = np.array([0, 100, 100])
        upper_red = np.array([10, 255, 255])
        red_mask = cv2.inRange(hsv_image, lower_red, upper_red)
        red_mask = cv2.erode(red_mask, None, iterations=2)
        red_mask = cv2.dilate(red_mask, None, iterations=2)
        contours, _ = cv2.findContours(red_mask.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        if len(contours) > 0:
            self.red_cube_detected = True
            cv2.drawContours(cv_image, contours, -1, (0, 255, 0), 3)
            cv2.imshow("Tello Camera", cv_image)
            cv2.waitKey(1)
        else:
            self.red_cube_detected = False

    def destroy_node(self):
        cmd_publish = Twist()
        self.publisher_.publish(cmd_publish)
        super().destroy_node()

    def publish_tf_transform(self, x, y, z):
        tf_transform = TransformStamped()
        tf_transform.header.stamp = self.get_clock().now().to_msg()
        tf_transform.header.frame_id = 'tello'
        tf_transform.child_frame_id = 'turtlebot'
        tf_transform.transform.translation.x = x
        tf_transform.transform.translation.y = y
        tf_transform.transform.translation.z = z
        tf_transform.transform.rotation.x = 0.0
        tf_transform.transform.rotation.y = 0.0
        tf_transform.transform.rotation.z = 0.0
        tf_transform.transform.rotation.w = 1.0
        self.tf_broadcaster.sendTransform(tf_transform)

    def update_tf_transform(self):
        try:
            transform = self.tf_buffer.lookup_transform('world', 'tello', rclpy.time.Time())
            self.get_logger().info('Transform: {}'.format(transform))
            self.tello_coordinates = transform.transform.translation
        except (tf2_ros.LookupException, tf2_ros.ConnectivityException, tf2_ros.ExtrapolationException):
            pass

    def move_to_vicinity_of_red_cube(self):
        cmd_publish = Twist()
        cmd_publish.linear.x = 0.1  # Adjusting the linear velocity
        self.publisher_.publish(cmd_publish)

    def stop_moving(self):
        cmd_publish = Twist()
        cmd_publish.linear.x = 0.0
        self.publisher_.publish(cmd_publish)

        if self.tello_coordinates is not None:
            x = self.tello_coordinates.x
            y = self.tello_coordinates.y
            z = self.tello_coordinates.z

            if abs(x) < self.vicinity_threshold and abs(y) < self.vicinity_threshold and abs(z) < self.vicinity_threshold:
                self.publish_tf_transform(x, y, z)
                self.get_logger().info('Tello coordinates sent: x={}, y={}, z={}'.format(x, y, z))
                self.call_tello_action(x, y, z)  # Calling TelloAction service

    def call_tello_action(self, x, y, z):
        self.req.x = x
        self.req.y = y
        self.req.z = z
        future = self.cli.call_async(self.req)
        rclpy.spin_until_future_complete(self, future)
        if future.result() is not None:
            self.get_logger().info('TelloAction response: {}'.format(future.result().response))
        else:
            self.get_logger().info('Failed to call TelloAction service')

    def takeoff(self):
        cmd_publish = Twist()
        cmd_publish.linear.z = 0.3  # Adjusting the takeoff velocity
        self.publisher_.publish(cmd_publish)
        self.get_logger().info('Tello takeoff')

    def land(self):
        cmd_publish = Twist()
        cmd_publish.linear.z = -0.3  # Adjusting the landing velocity
        self.publisher_.publish(cmd_publish)
        self.get_logger().info('Tello land')


def main(args=None):
    rclpy.init(args=args)
    tello_node = TelloNode()

    while rclpy.ok():
        rclpy.spin_once(tello_node)
        tello_node.update_tf_transform()

        if not tello_node.red_cube_detected:
            tello_node.move_to_vicinity_of_red_cube()
        else:
            tello_node.stop_moving()

    tello_node.land()
    tello_node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()